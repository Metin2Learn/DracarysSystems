# add

#define ENABLE_GUILD_REQUEST

