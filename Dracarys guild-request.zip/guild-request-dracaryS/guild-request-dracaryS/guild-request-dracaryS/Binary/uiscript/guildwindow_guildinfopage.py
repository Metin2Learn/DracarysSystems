# Add

		{
			"name" : "requestButton",
			"type" : "button",
			"x" : 10,
			"y" : 270,
			"default_image" : "d:/ymir work/ui/game/guild_request/refresh_0.tga",
			"over_image" : "d:/ymir work/ui/game/guild_request/refresh_1.tga",
			"down_image" : "d:/ymir work/ui/game/guild_request/refresh_2.tga",
		},
