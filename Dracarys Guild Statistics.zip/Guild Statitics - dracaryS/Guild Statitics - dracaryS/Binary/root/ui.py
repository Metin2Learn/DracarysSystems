
# Add in Class Button

	def SetAlpha(self, alpha):
		self.SetButtonColor(1.0,1.0,1.0,alpha)

	def SetButtonColorRGB(self, r, g, b, alpha):
		self.buttonColorR = float(r)/255.0
		self.buttonColorG = float(g)/255.0
		self.buttonColorB = float(b)/255.0
		self.buttonColorA = alpha

		wndMgr.SetButtonColor(self.hWnd, float(r)/255.0, float(g)/255.0, float(b)/255.0, alpha)

	def SetButtonColor(self, r, g, b, alpha):
		self.buttonColorR = r
		self.buttonColorG = g
		self.buttonColorB = b
		self.buttonColorA = alpha

		wndMgr.SetButtonColor(self.hWnd, r, g, b, alpha)

	def GetButtonColor(self):
		return self.buttonColorR, self.buttonColorG, self.buttonColorB, self.buttonColorA


# Add

class MultiTextLine(Window):
	def __del__(self):
		Window.__del__(self)
	def Destroy(self):
		self.children = []
		self.rangeText = 0
	def __init__(self):
		Window.__init__(self)
		self.children = []
		self.rangeText = 15
		self.textType = ""
	def SetTextType(self, textType):
		self.textType = textType
		for text in self.children:
			self.AddTextType(self.textType.split("#"),text)
	def SetTextRange(self, range):
		self.rangeText = range
		yPosition = 0
		for text in self.children:
			text.SetPosition(0,yPosition)
			yPosition+=self.rangeText
	def AddTextType(self, typeArg, text):
		if len(typeArg) > 1:
			if typeArg[0] == "vertical":
				if typeArg[1] == "top":
					text.SetVerticalAlignTop()
				elif typeArg[1] == "bottom":
					text.SetVerticalAlignBottom()
				elif typeArg[1] == "center":
					text.SetVerticalAlignCenter()
			elif typeArg[0] == "horizontal":
				if typeArg[1] == "left":
					text.SetHorizontalAlignLeft()
				elif typeArg[1] == "right":
					text.SetHorizontalAlignRight()
				elif typeArg[1] == "center":
					text.SetHorizontalAlignCenter()
	def SetText(self, cmd):
		if len(self.children) > 1:
			self.children=[]
		multi_arg = cmd.split("\n")
		yPosition = 0
		for text in multi_arg:
			childText = TextLine()
			childText.SetParent(self)
			childText.SetPosition(0,yPosition)
			if self.textType != "":
				self.AddTextType(self.textType.split("#"),childText)
			childText.SetText(str(text))
			childText.Show()
			self.children.append(childText)
			yPosition+=self.rangeText
