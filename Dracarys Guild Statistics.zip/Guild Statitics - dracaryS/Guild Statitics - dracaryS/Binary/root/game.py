# Search

		onPressKeyDict[app.DIK_F8]	= lambda : self.SetFreeCameraMode(True)

# Add before

		if app.GUILD_WAR_COUNTER:
			if background.GetCurrentMapName() == "metin2_map_t3":
				onPressKeyDict[app.DIK_TAB]	= lambda : self.OpenGuildWarStatics()


# Search

	self.interface = interfaceModule.Interface()

# Add after

	constInfo.SetInterfaceInstance(self.interface)

# Search

	self.KillFocus()

# Add after

	constInfo.SetInterfaceInstance(None)

# Search

	if app.__IMPROVED_GUILD_WAR__:
		def BINARY_GuildWar_OnStart(self, guildSelf, guildOpp, iMaxPlayer, iMaxScore, flags):
			self.interface.OnStartGuildWar(guildSelf, guildOpp)
			if app.GUILD_WAR_COUNTER:
				self.interface.GuildWarStaticSetGuildID(guildSelf, guildOpp,iMaxPlayer, iMaxScore, flags)
	else:
		def BINARY_GuildWar_OnStart(self, guildSelf, guildOpp):
			self.interface.OnStartGuildWar(guildSelf, guildOpp)

# Change

	if app.__IMPROVED_GUILD_WAR__:
		def BINARY_GuildWar_OnStart(self, guildSelf, guildOpp, iMaxPlayer, iMaxScore, flags):
			self.interface.OnStartGuildWar(guildSelf, guildOpp)
			if app.GUILD_WAR_COUNTER:
				self.interface.GuildWarStaticSetGuildID(guildSelf, guildOpp,iMaxPlayer, iMaxScore, flags)
	else:
		def BINARY_GuildWar_OnStart(self, guildSelf, guildOpp):
			self.interface.OnStartGuildWar(guildSelf, guildOpp)
			if app.GUILD_WAR_COUNTER:
				self.interface.GuildWarStaticSetGuildID(guildSelf, guildOpp)

# Add

	if app.GUILD_WAR_COUNTER:
		def OpenGuildWarStatics(self):
			self.interface.OpenGuildWarStatics()
		def SetStaticsStatus(self):
			self.interface.SetStaticsStatus()
		def GuildWarStaticsUpdate(self):
			self.interface.GuildWarStaticsUpdate()
		def GuildWarStaticsClear(self):
			self.interface.GuildWarStaticsClear()
		def GuildWarStaticsSpecial(self, pid, sub_index):
			self.interface.GuildWarStaticsSpecial(pid, sub_index)
		def GuildWarUpdateUserCount(self, id0, user0, id1, user1, observer):
			self.interface.UpdateMemberCount(int(id0), int(user0), int(id1), int(user1))
			self.interface.wndMiniMap.UpdateObserverCount(int(observer))
			self.interface.GuildWarStaticSetUser(int(id0), int(user0), int(id1), int(user1), int(observer))
		def UpdateObserverCount(self, observer):
			self.interface.UpdateObserverCount(observer)
		def AddCSMessage(self, killerName, killerRace, victimName, victimRace):
			self.interface.AddCSMessage(str(killerName), int(killerRace), str(victimName), int(victimRace))
