# Add

if app.GUILD_WAR_COUNTER:
	import uiGuildWar


# Search

		self.wndItemSelect=None

# Add after

		if app.GUILD_WAR_COUNTER:
			self.wndGuildWar = None
			self.wndGuildWarCSMsg = None

# search 

	def Close(self):

# add after

		if app.GUILD_WAR_COUNTER:
			if self.wndGuildWar:
				self.wndGuildWar.Destroy()
				self.wndGuildWar.Hide()
				self.wndGuildWar = None
			if self.wndGuildWarCSMsg:
				self.wndGuildWarCSMsg.Destroy()
				self.wndGuildWarCSMsg.Hide()
				self.wndGuildWarCSMsg = None

# Add


	if app.GUILD_WAR_COUNTER:
		def __MakeGuildWar(self):
			uiGuildWar.MAIN_VID = player.GetName()
			uiGuildWar.CURRENT_VID = ""
			if self.wndGuildWar == None:
				self.wndGuildWar = uiGuildWar.GuildWarStatic()

		def OpenGuildWarStatics(self):
			self.__MakeGuildWar()
			if self.wndGuildWar.IsShow():
				self.wndGuildWar.Hide()
			else:
				self.wndGuildWar.Open()
		def SetStaticsStatus(self):
			if self.wndGuildWar:
				self.wndGuildWar.SetStaticsStatus()
		def GuildWarStaticsUpdate(self):
			if self.wndGuildWar:
				self.wndGuildWar.Update()
		def GuildWarStaticsClear(self):
			if self.wndGuildWar:
				self.wndGuildWar.Clear()
		def GuildWarStaticsSpecial(self, pid, sub_index):
			if self.wndGuildWar:
				self.wndGuildWar.GuildWarStaticsSpecial(pid, sub_index)

		def GuildWarStaticSetGuildID(self, firstID, secondID):
			self.__MakeGuildWar()
			if self.wndGuildWar:
				self.wndGuildWar.SetGuildID(int(firstID), int(secondID))

		def GuildWarStaticSetUser(self, id0, user0, id1, user1, observer):
			if self.wndGuildWar:
				self.wndGuildWar.SetUser(id0, user0, id1, user1, observer)

		def GuildWarStaticSetScore(self, id0, id1, score):
			if self.wndGuildWar:
				self.wndGuildWar.SetScore(id0, id1, score)

		def UpdateObserverCount(self, observer):
			if self.wndGuildWar:
				self.wndGuildWar.UpdateObserverCount(observer)

		def MakeCSMessage(self):
			if self.wndGuildWarCSMsg == None:
				self.wndGuildWarCSMsg = uiGuildWar.MessageQueue()
				self.wndGuildWarCSMsg.Show()

		def AddCSMessage(self, killerName, killerRace, victimName, victimRace):
			self.MakeCSMessage()
			if self.wndGuildWarCSMsg:
				self.wndGuildWarCSMsg.OnMessage(killerName, killerRace, victimName, victimRace)
