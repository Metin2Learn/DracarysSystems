# Add

if app.GUILD_WAR_COUNTER:
	import constInfo

# Search

	self.gameButtonDict["EXIT_OBSERVER"].SetEvent(ui.__mem_func__(self.__OnClickExitObserver))

# Add after

	if app.GUILD_WAR_COUNTER:
		self.gameButtonDict["EXIT_CAMERA_MODE"] = self.GetChild("ExitCameraMode")
		self.gameButtonDict["EXIT_CAMERA_MODE"].SetEvent(ui.__mem_func__(self.__OnClickExitCameraMode))

# Add

	if app.GUILD_WAR_COUNTER:
		def __OnClickExitCameraMode(self):
			interface = constInfo.GetInterfaceInstance()
			if interface != None:
				if interface.wndGuildWar:
					interface.wndGuildWar.ExitCameraMode()

		def UpdateCameraMode(self):
			isEnable = player.GetCameraMode()
			if isEnable:
				self.gameButtonDict["EXIT_CAMERA_MODE"].Show()
			else:
				self.gameButtonDict["EXIT_CAMERA_MODE"].Hide()
	