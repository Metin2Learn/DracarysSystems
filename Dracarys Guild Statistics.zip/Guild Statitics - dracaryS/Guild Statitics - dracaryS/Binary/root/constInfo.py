# Add

_interface_instance = None
def GetInterfaceInstance():
	global _interface_instance
	return _interface_instance
def SetInterfaceInstance(instance):
	global _interface_instance
	if _interface_instance:
		del _interface_instance
	_interface_instance = instance
def raceToJob(race):
	if race == 0 or race == 4:#warrior
		return 0
	elif race == 1 or race == 5:#assassin
		return 1
	elif race == 2 or race == 6:#sura
		return 2
	elif race == 3 or race == 7:#shaman
		return 3
	return 0
def IS_SET(value, flag):
	return (value & flag) == flag
def SET_BIT(value, bit):
	return value | (bit)
def REMOVE_BIT(value, bit):
	return value & ~(bit)
def getFlagValue(value):
	return 1 << value