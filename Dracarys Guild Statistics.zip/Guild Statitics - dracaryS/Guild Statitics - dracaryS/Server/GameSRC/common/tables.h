# Add

#ifdef GUILD_WAR_COUNTER
typedef struct war_static_
{
	BYTE	empire;
	char	name[CHARACTER_NAME_MAX_LEN + 1];
	BYTE	level;
	BYTE	race;
	BYTE	kill;
	BYTE	dead;
	long	skill_dmg;
	bool	is_leader;
	DWORD	guild_id;
	DWORD	pid;
	bool	spy;
	bool	online;
} war_static_ptr;
#endif