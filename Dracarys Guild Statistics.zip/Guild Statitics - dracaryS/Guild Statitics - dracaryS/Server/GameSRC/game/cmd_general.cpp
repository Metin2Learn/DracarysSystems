# Add

#ifdef GUILD_WAR_COUNTER
ACMD(do_guild_war_static)
{
	std::vector<std::string> vecArgs;
	split_argument(argument, vecArgs);
	if (vecArgs.size() < 2) { return; }
	if (vecArgs[1] == "load")
	{
		if (ch->GetProtectTime("update_static_load") == 0)
		{
			if (CWarMapManager::instance().IsWarMap(ch->GetMapIndex()))
			{
				CWarMap* pMap = CWarMapManager::instance().Find(ch->GetMapIndex());
				if (pMap)
				{
					std::vector<war_static_ptr> list;
					pMap->UpdateStatic(ch, GUILD_STATIC_LOAD, list);
					ch->SetProtectTime("update_static_load", 1);
				}
			}
		}
	}
	else if (vecArgs[1] == "spy")
	{
		if (!ch->GetGuild())
			return;

		if (!(ch->GetGuild() && ch->GetGuild()->GetMasterPID() == ch->GetPlayerID()))
			return;
		if (vecArgs.size() < 4) { return; }

		DWORD spy_pid;
		str_to_number(spy_pid, vecArgs[3].c_str());
		ch->GetGuild()->RequestRemoveMember(spy_pid);

		LPCHARACTER spy = CHARACTER_MANAGER::Instance().FindByPID(spy_pid);
		if (spy)
		{
			if (CWarMapManager::instance().IsWarMap(spy->GetMapIndex()))
				spy->ExitToSavedLocation();
		}

		if (CWarMapManager::instance().IsWarMap(ch->GetMapIndex()))
		{
			CWarMap* pMap = CWarMapManager::instance().Find(ch->GetMapIndex());
			if (pMap)
				pMap->UpdateSpy(spy_pid);
		}
	}
}
#endif
