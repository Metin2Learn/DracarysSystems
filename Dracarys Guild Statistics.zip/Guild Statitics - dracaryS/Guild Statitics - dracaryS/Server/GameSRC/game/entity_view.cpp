# Search

	if ((DISTANCE_APPROX(ent->GetX() - m_me->GetX(), ent->GetY() - m_me->GetY()) > dwViewRange))

# Add before

#ifdef GUILD_WAR_COUNTER
			if(!((m_me->GetMapIndex() >= 1100000 && m_me->GetMapIndex() <= 1109999) && !m_me->IsObserverMode()))
#endif

# Search

if (m_bObserverModeChange)

# Add before

#ifdef GUILD_WAR_COUNTER
	bool isCameraNeed = false;
	if (IsType(ENTITY_CHARACTER))
	{
		LPCHARACTER tch = (LPCHARACTER)this;
		if (tch)
		{
			if ((tch->GetMapIndex() >= 1100000 && tch->GetMapIndex() <= 1109999) && !tch->IsObserverMode())
				isCameraNeed = true;
		}
	}
#endif

# Search


		if (!m_bIsObserver)
		{
			auto it = m_map_view.begin();

			while (it != m_map_view.end())
			{
				auto this_it = it++;
				LPENTITY ent = this_it->first;
				if (this_it->second < m_iViewAge)
				{
					ent->EncodeRemovePacket(this);
					m_map_view.erase(this_it);
					ent->ViewRemove(this, false);
				}
			}
		}

# Change


		if (!m_bIsObserver)
		{
			auto it = m_map_view.begin();

			while (it != m_map_view.end())
			{
				auto this_it = it++;

				LPENTITY ent = this_it->first;

#ifdef GUILD_WAR_COUNTER
				if (isCameraNeed)
				{
					if (ent->IsType(ENTITY_CHARACTER))
					{
						LPCHARACTER pch = (LPCHARACTER)ent;
						if (pch)
						{
							if (pch->IsObserverMode())
								continue;
						}
					}
				}
#endif

				if (this_it->second < m_iViewAge)
				{
					ent->EncodeRemovePacket(this);
					m_map_view.erase(this_it);
					ent->ViewRemove(this, false);
				}
			}
		}