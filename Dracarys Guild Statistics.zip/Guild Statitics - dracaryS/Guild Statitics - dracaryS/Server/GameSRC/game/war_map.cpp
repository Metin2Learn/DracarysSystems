#Search

	ch->SetObserverMode(true);

# Add after

#ifdef GUILD_WAR_COUNTER
		std::vector<war_static_ptr> list;
		UpdateStatic(ch, GUILD_STATIC_UPDATE_OBSERVER, list);
#endif


# Search

	ch->SetObserverMode(false);

# Add after

#ifdef GUILD_WAR_COUNTER
		std::vector<war_static_ptr> m_list;
		UpdateStatic(NULL, GUILD_STATIC_UPDATE_OBSERVER, m_list);
#endif

# Search

	auto it = m_set_pkChr.begin();
	while (it != m_set_pkChr.end())
	{
		LPCHARACTER ch = *(it++);
		if (ch->GetDesc())
		{
			sys_log(0, "WarMap::~WarMap : disconnecting %s", ch->GetName());
			DESC_MANAGER::instance().DestroyDesc(ch->GetDesc());
		}
	}

# Change

#ifdef GUILD_WAR_COUNTER
	for (auto it = m_set_pkChr.begin(); it != m_set_pkChr.end(); ++it)
	{
		LPCHARACTER ch = CHARACTER_MANAGER::Instance().FindByPID(it->first);
		if (ch && ch->GetDesc())
		{
			sys_log(0, "WarMap::~WarMap : disconnecting %s", ch->GetName());
			DESC_MANAGER::instance().DestroyDesc(ch->GetDesc());
		}
	}
#else
	auto it = m_set_pkChr.begin();
	while (it != m_set_pkChr.end())
	{
		LPCHARACTER ch = *(it++);
		if (ch->GetDesc())
		{
			sys_log(0, "WarMap::~WarMap : disconnecting %s", ch->GetName());
			DESC_MANAGER::instance().DestroyDesc(ch->GetDesc());
		}
	}
#endif

# Search

struct FSendUserCount
{
	char buf1[30];
	char buf2[128];

	FSendUserCount(DWORD g1, int g1_count, DWORD g2, int g2_count, int observer)
	{
		snprintf(buf1, sizeof(buf1), "ObserverCount %d", observer);
		snprintf(buf2, sizeof(buf2), "WarUC %u %d %u %d %d", g1, g1_count, g2, g2_count, observer);
	}

	void operator() (LPCHARACTER ch)
	{
		ch->ChatPacket(CHAT_TYPE_COMMAND, buf1);
		ch->ChatPacket(CHAT_TYPE_COMMAND, buf2);
	}
};

# Change

#ifndef GUILD_WAR_COUNTER
struct FSendUserCount
{
	char buf1[30];
	char buf2[128];

	FSendUserCount(DWORD g1, int g1_count, DWORD g2, int g2_count, int observer)
	{
		snprintf(buf1, sizeof(buf1), "ObserverCount %d", observer);
		snprintf(buf2, sizeof(buf2), "WarUC %u %d %u %d %d", g1, g1_count, g2, g2_count, observer);
	}

	void operator() (LPCHARACTER ch)
	{
		ch->ChatPacket(CHAT_TYPE_COMMAND, buf1);
		ch->ChatPacket(CHAT_TYPE_COMMAND, buf2);
	}
};
#endif

# Search

void CWarMap::UpdateUserCount()

# Change

void CWarMap::UpdateUserCount()
{
#ifdef GUILD_WAR_COUNTER
	char buf1[30];
	char buf2[128];
	snprintf(buf1, sizeof(buf1), "ObserverCount %d", m_iObserverCount);
	snprintf(buf2, sizeof(buf2), "WarUC %u %d %u %d %d", m_TeamData[0].dwID, m_TeamData[0].GetCurJointerCount(), m_TeamData[1].dwID, m_TeamData[1].GetCurJointerCount(), m_iObserverCount);
	for (auto it = m_set_pkChr.begin(); it != m_set_pkChr.end(); ++it)
	{
		LPCHARACTER ch = CHARACTER_MANAGER::Instance().FindByPID(it->first);
		if (ch)
		{
			ch->ChatPacket(CHAT_TYPE_COMMAND, buf1);
			ch->ChatPacket(CHAT_TYPE_COMMAND, buf2);
		}
	}
#else
	//FSendUserCount f(m_TeamData[0].dwID, m_TeamData[0].GetAccumulatedJoinerCount(), m_TeamData[1].dwID, m_TeamData[1].GetAccumulatedJoinerCount(), m_iObserverCount);
	FSendUserCount f(m_TeamData[0].dwID, m_TeamData[0].GetCurJointerCount(), m_TeamData[1].dwID, m_TeamData[1].GetCurJointerCount(), m_iObserverCount);
	std::for_each(m_set_pkChr.begin(), m_set_pkChr.end(), f);
#endif

}

# Search

m_TeamData[0].AppendMember(ch);

# Add after

#ifdef GUILD_WAR_COUNTER
			RegisterStatics(ch);
#endif

# Search

m_TeamData[1].AppendMember(ch);

# Add after

#ifdef GUILD_WAR_COUNTER
			RegisterStatics(ch);
#endif

# Search

m_set_pkChr.insert(ch);

# Change

#ifdef GUILD_WAR_COUNTER
	m_set_pkChr.emplace(ch->GetPlayerID(),false);
#else
	m_set_pkChr.insert(ch);
#endif

# Search

	SendScorePacket(0, d);
	SendScorePacket(1, d);
	UpdateUserCount();

# Change

#ifdef GUILD_WAR_COUNTER
	std::vector<war_static_ptr> list;
	UpdateStatic(ch, GUILD_STATIC_LOAD, list);
#else
	SendScorePacket(0, d);
	SendScorePacket(1, d);
	UpdateUserCount();
#endif


# Search

	UpdateUserCount();
	m_set_pkChr.erase(ch);

# Change

#ifdef GUILD_WAR_COUNTER
	auto it = war_static.find(ch->GetPlayerID());
	if (it != war_static.end())
	{
		it->second.online = false;
		std::vector<war_static_ptr> m_list;
		m_list.clear();
		m_list.emplace_back(it->second);
		UpdateStatic(NULL, GUILD_STATIC_UPDATE_ONLINE, m_list);
	}
	m_set_pkChr.erase(ch->GetPlayerID());
#else
	UpdateUserCount();
	m_set_pkChr.erase(ch);
#endif

# Search

struct FExitGuildWar
{
	void operator() (LPCHARACTER ch)
	{
		if (ch->IsPC())
		{
			ch->ExitToSavedLocation();
		}
	}
};

# Change

#ifndef GUILD_WAR_COUNTER
struct FExitGuildWar
{
	void operator() (LPCHARACTER ch)
	{
		if (ch->IsPC())
		{
			ch->ExitToSavedLocation();
		}
	}
};
#endif

# Search

void CWarMap::ExitAll()

# Change

void CWarMap::ExitAll()
{
#ifdef GUILD_WAR_COUNTER
	for (auto it = m_set_pkChr.begin(); it != m_set_pkChr.end(); ++it)
	{
		LPCHARACTER ch = CHARACTER_MANAGER::Instance().FindByPID(it->first);
		if (ch)
			ch->ExitToSavedLocation();
	}
#else
	FExitGuildWar f;
	std::for_each(m_set_pkChr.begin(), m_set_pkChr.end(), f);
#endif
}

# Search

namespace
{
	struct FPacket
	{
		FPacket(const void* p, int size) : m_pvData(p), m_iSize(size){}
		void operator () (LPCHARACTER ch)
		{
			ch->GetDesc()->Packet(m_pvData, m_iSize);
		}
		const void* m_pvData;
		int m_iSize;
	};
	struct FNotice
	{
		FNotice(const char* psz) : m_psz(psz){}
		void operator() (LPCHARACTER ch)
		{
			ch->ChatPacket(CHAT_TYPE_NOTICE, "%s", m_psz);
		}
		const char* m_psz;
	};

};

# Change

#ifndef GUILD_WAR_COUNTER
namespace
{
	struct FPacket
	{
		FPacket(const void* p, int size) : m_pvData(p), m_iSize(size){}
		void operator () (LPCHARACTER ch)
		{
			ch->GetDesc()->Packet(m_pvData, m_iSize);
		}
		const void* m_pvData;
		int m_iSize;
	};
	struct FNotice
	{
		FNotice(const char* psz) : m_psz(psz){}
		void operator() (LPCHARACTER ch)
		{
			ch->ChatPacket(CHAT_TYPE_NOTICE, "%s", m_psz);
		}
		const char* m_psz;
	};

};
#endif

# Search

void CWarMap::Notice(const char* psz)

# Change

void CWarMap::Notice(const char* psz)
{
#ifdef GUILD_WAR_COUNTER
	for (auto it = m_set_pkChr.begin(); it != m_set_pkChr.end(); ++it)
	{
		LPCHARACTER ch = CHARACTER_MANAGER::Instance().FindByPID(it->first);
		if (ch)
			ch->ChatPacket(CHAT_TYPE_NOTICE, "%s", psz);
}
#else
	FNotice f(psz);
	std::for_each(m_set_pkChr.begin(), m_set_pkChr.end(), f);
#endif
}

# Search

void CWarMap::Packet(const void* p, int size, bool broadcast)

# Change

void CWarMap::Packet(const void* p, int size, bool broadcast)
{
#ifdef GUILD_WAR_COUNTER
	for (auto it = m_set_pkChr.begin(); it != m_set_pkChr.end(); ++it)
	{
		if (broadcast && !it->second)
			continue;

		LPCHARACTER ch = CHARACTER_MANAGER::Instance().FindByPID(it->first);
		if (ch)
			ch->GetDesc()->Packet(p, size);
	}
#else
	FPacket f(p, size);
	std::for_each(m_set_pkChr.begin(), m_set_pkChr.end(), f);
#endif
}


# search x2

			SendScorePacket(idx);

# Change x2

#ifndef GUILD_WAR_COUNTER
			SendScorePacket(idx);
#endif

# Search

	SendGuildWarScore(dwKillerGuild, dwDeadGuild, 1, ch->GetLevel());

# Add after

#ifdef GUILD_WAR_COUNTER
		SendKillNotice(killer,ch);
#endif


# Search

struct FRemoveFlagAffect
{
	void operator() (LPCHARACTER ch)
	{
		if (ch->FindAffect(AFFECT_WAR_FLAG))
			ch->RemoveAffect(AFFECT_WAR_FLAG);
	}
};

# Change

#ifndef GUILD_WAR_COUNTER
struct FRemoveFlagAffect
{
	void operator() (LPCHARACTER ch)
	{
		if (ch->FindAffect(AFFECT_WAR_FLAG))
			ch->RemoveAffect(AFFECT_WAR_FLAG);
	}
};
#endif

# Search

	FRemoveFlagAffect f;
	std::for_each(m_set_pkChr.begin(), m_set_pkChr.end(), f);

# Change

#ifdef GUILD_WAR_COUNTER
	for (auto it = m_set_pkChr.begin(); it != m_set_pkChr.end(); ++it)
	{
		LPCHARACTER ch = CHARACTER_MANAGER::Instance().FindByPID(it->first);
		if (ch)
		{
			if (ch->FindAffect(AFFECT_WAR_FLAG))
				ch->RemoveAffect(AFFECT_WAR_FLAG);
		}
	}
#else
	FRemoveFlagAffect f;
	std::for_each(m_set_pkChr.begin(), m_set_pkChr.end(), f);
#endif




# Add

#ifdef GUILD_WAR_COUNTER
void CWarMap::UpdateStatic(LPCHARACTER ch, BYTE sub_index, std::vector<war_static_ptr> m_list)
{
	TPacketGCGuildStatic p;
	p.header = HEDAER_GC_GUILD_WAR;
	p.sub_index = sub_index;
	if (sub_index == GUILD_STATIC_LOAD)
	{
		if (!ch)
			return;
		auto it = m_set_pkChr.find(ch->GetPlayerID());
		if (it == m_set_pkChr.end())
			return;
		if (it->second)
			return;

		it->second = true;
		if (war_static.size())
		{
			p.packet_size = war_static.size();
			p.size = sizeof(p) + (sizeof(war_static_ptr) * war_static.size());
			std::vector<war_static_ptr> m_data;
			m_data.clear();
			for (auto it = war_static.begin(); it != war_static.end(); ++it)
				m_data.emplace_back(it->second);
			ch->GetDesc()->BufferedPacket(&p, sizeof(p));
			ch->GetDesc()->Packet(m_data.data(), sizeof(war_static_ptr)* p.packet_size);
		}
		else
		{
			p.sub_index = 99;
			p.size = sizeof(p);
			ch->GetDesc()->Packet(&p, sizeof(p));
		}
	}
	else if (GUILD_STATIC_UPDATE_OBSERVER == sub_index)
	{
		p.size = sizeof(p) + sizeof(m_iObserverCount);
		TEMP_BUFFER buf;
		buf.write(&p, sizeof(p));
		buf.write(&m_iObserverCount, sizeof(m_iObserverCount));
		Packet(buf.read_peek(), buf.size(), true);
	}
	else
	{
		for (auto it = m_list.begin(); it != m_list.end(); ++it)
			sys_err("name %s level %d empire %d race %d", it->name, it->level, it->empire, it->race);

		p.size = sizeof(p) + (sizeof(war_static_ptr) * m_list.size());
		p.packet_size = m_list.size();
		TEMP_BUFFER buf;
		buf.write(&p, sizeof(p));
		buf.write(m_list.data(), sizeof(war_static_ptr) * p.packet_size);
		Packet(buf.read_peek(), buf.size(), true);
	}
}

void CWarMap::RegisterStatics(LPCHARACTER ch)
{
	auto it = war_static.find(ch->GetPlayerID());
	if (it == war_static.end())
	{
		war_static_ptr ptr;
		memset(&ptr, 0, sizeof(ptr));
		ptr.empire = ch->GetEmpire();
		strlcpy(ptr.name, ch->GetName(), sizeof(ptr.name));
		ptr.pid = ch->GetPlayerID();
		ptr.level = ch->GetLevel();
		ptr.race = ch->GetRaceNum();
		ptr.guild_id = ch->GetGuild()->GetID();
		ptr.is_leader = ch->GetPlayerID() == ch->GetGuild()->GetMasterPID();
		ptr.online = true;
		war_static.emplace(ch->GetPlayerID(), ptr);

		std::vector<war_static_ptr> m_list;
		m_list.clear();
		m_list.emplace_back(ptr);
		UpdateStatic(NULL, GUILD_STATIC_ADD_MEMBER, m_list);
	}
	else
	{
		if (!it->second.online)
		{
			it->second.online = true;
			std::vector<war_static_ptr> m_list;
			m_list.clear();
			m_list.emplace_back(it->second);
			UpdateStatic(NULL, GUILD_STATIC_UPDATE_ONLINE, m_list);
		}
	}
}

void CWarMap::UpdateSpy(DWORD pid)
{
	auto spy_it = war_static.find(pid);
	if (spy_it != war_static.end())
	{
		spy_it->second.spy = true;
		std::vector<war_static_ptr> m_list;
		m_list.clear();
		m_list.emplace_back(spy_it->second);
		UpdateStatic(NULL, GUILD_STATIC_SPY, m_list);
	}
}
void CWarMap::SendKillNotice(LPCHARACTER killer, LPCHARACTER victim, long damage)
{
	if (m_bEnded)
		return;
	//DWORD team_ID = killer->GetProtectTime("guild_team");
	//if (team_ID >= 1 && team_ID <= 2)
	{
		std::vector<war_static_ptr> m_list;
		m_list.clear();
		if (killer)
		{
			auto killer_it = war_static.find(killer->GetPlayerID());
			if (killer_it != war_static.end())
			{
				if (damage > 0)
				{
					killer_it->second.skill_dmg += damage;
					m_list.emplace_back(killer_it->second);
					UpdateStatic(NULL, GUILD_STATIC_DMG, m_list);
					return;
				}
				else
				{
					killer_it->second.kill += 1;
					m_list.emplace_back(killer_it->second);
				}
			}
		}

		if (victim)
		{
			auto victim_it = war_static.find(victim->GetPlayerID());
			if (victim_it != war_static.end())
			{
				victim_it->second.dead += 1;
				m_list.emplace_back(victim_it->second);
			}
		}
		UpdateStatic(NULL, GUILD_STATIC_KILL_DEAD, m_list);
	}
}


#endif
