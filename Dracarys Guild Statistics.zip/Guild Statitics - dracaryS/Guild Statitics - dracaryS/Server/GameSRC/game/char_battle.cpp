# Add

#ifdef GUILD_WAR_COUNTER
#include "war_map.h"
#endif


# Search

	if (!IsPC())
	{
		if (m_pkParty && m_pkParty->GetLeader())
			m_pkParty->GetLeader()->SetLastAttacked(get_dword_time());
		else
			SetLastAttacked(get_dword_time());
	}

# Add after

#ifdef GUILD_WAR_COUNTER
	if (type == DAMAGE_TYPE_MELEE 
		|| type == DAMAGE_TYPE_RANGE
		|| type == DAMAGE_TYPE_FIRE
		|| type == DAMAGE_TYPE_ICE
		|| type == DAMAGE_TYPE_ELEC
		|| type == DAMAGE_TYPE_MAGIC)
	{
		if (CWarMapManager::instance().IsWarMap(GetMapIndex()))
		{
			CWarMap* pMap = CWarMapManager::instance().Find(GetMapIndex());
			if (pMap)
			{
				CGuild* attackerGuild = pAttacker->GetGuild();
				CGuild* victimGuild = GetGuild();
				if (attackerGuild && victimGuild)
					if (attackerGuild->UnderWar(victimGuild->GetID()))
						pMap->SendKillNotice(pAttacker, this, dam);
			}
		}
	}
#endif

