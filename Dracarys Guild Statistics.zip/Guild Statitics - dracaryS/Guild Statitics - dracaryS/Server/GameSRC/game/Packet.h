# Search

	HEADER_GC_QUEST_CONFIRM = 46,

# Add after

#ifdef GUILD_WAR_COUNTER
	HEDAER_GC_GUILD_WAR = 57,
#endif


# Add

#ifdef GUILD_WAR_COUNTER
enum
{
	GUILD_STATIC_LOAD,
	GUILD_STATIC_KILL_DEAD,
	GUILD_STATIC_DMG,
	GUILD_STATIC_ADD_MEMBER,
	GUILD_STATIC_SPY,
	GUILD_STATIC_UPDATE_ONLINE,
	GUILD_STATIC_USER_COUNT,
	GUILD_STATIC_UPDATE_OBSERVER,
};
typedef struct SPacketGCGuildStatic
{
	BYTE	header;
	DWORD	size;
	BYTE	sub_index;
	BYTE	packet_size;
	//UINT	observer;
} TPacketGCGuildStatic;
#endif