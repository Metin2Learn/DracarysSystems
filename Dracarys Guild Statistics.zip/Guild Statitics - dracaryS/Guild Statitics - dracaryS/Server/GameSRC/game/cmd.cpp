# Search

#ifdef GUILD_WAR_COUNTER
ACMD(do_guild_war_static);
#endif

# Add after

#ifdef GUILD_WAR_COUNTER
ACMD(do_guild_war_static);
#endif

# Search

{ "\n",						NULL,						0,				POS_DEAD,		GM_PLAYER	}

# Add before

#ifdef GUILD_WAR_COUNTER
	{ "guild_war_static",	do_guild_war_static,		0,		POS_DEAD,	GM_PLAYER },
#endif

