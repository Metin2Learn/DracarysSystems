# Add

#ifdef GUILD_WAR_COUNTER
#include "war_map.h"
#endif


# Search

			m_memberOnline.erase(ch);
			ch->SetGuild(NULL);

# add after

#ifdef GUILD_WAR_COUNTER
		if (CWarMapManager::instance().IsWarMap(ch->GetMapIndex()))
		{
			ch->ExitToSavedLocation();
			CWarMap* pMap = CWarMapManager::instance().Find(ch->GetMapIndex());
			if (pMap)
				pMap->UpdateSpy(ch->GetPlayerID());
		}
#endif
