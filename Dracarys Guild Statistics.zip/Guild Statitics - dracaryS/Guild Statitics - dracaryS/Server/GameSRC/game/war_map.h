# Add

#ifdef GUILD_WAR_COUNTER
#include <array>
#endif

# Search

	void	Packet(const void* pv, int size);

# Change

#ifdef GUILD_WAR_COUNTER
	void	SendKillNotice(LPCHARACTER killer, LPCHARACTER victim, long damage = 0);
	void	UpdateStatic(LPCHARACTER ch, BYTE sub_index, std::vector<war_static_ptr> m_list);
	void	RegisterStatics(LPCHARACTER ch);
	void	UpdateSpy(DWORD pid);
	void	Packet(const void* pv, int size, bool broadcast = false);
#else
	void	Packet(const void* pv, int size);
#endif


#Search

	TeamData		m_TeamData[2];

# Add before

#ifdef GUILD_WAR_COUNTER
	std::map<DWORD, war_static_ptr> war_static;
#endif

# Search

	CHARACTER_SET	m_set_pkChr;

# Change

#ifdef GUILD_WAR_COUNTER
	std::map<DWORD, bool>	m_set_pkChr;
#else
	CHARACTER_SET	m_set_pkChr;
#endif

