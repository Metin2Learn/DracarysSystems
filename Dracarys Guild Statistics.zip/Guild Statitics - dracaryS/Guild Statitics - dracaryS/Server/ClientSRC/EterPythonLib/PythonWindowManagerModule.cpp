

# Search

	void initwndMgr()

# Add before


PyObject* wndButtonSetColor(PyObject* poSelf, PyObject* poArgs)
{
	UI::CWindow* pWindow;
	if (!PyTuple_GetWindow(poArgs, 0, &pWindow))
		return Py_BuildException();
	float r;
	if (!PyTuple_GetFloat(poArgs, 1, &r))
		return Py_BuildException();
	float g;
	if (!PyTuple_GetFloat(poArgs, 2, &g))
		return Py_BuildException();
	float b;
	if (!PyTuple_GetFloat(poArgs, 3, &b))
		return Py_BuildException();
	float alpha;
	if (!PyTuple_GetFloat(poArgs, 4, &alpha))
		return Py_BuildException();

	((UI::CButton*)pWindow)->SetButtonColor(r, g, b, alpha);
	return Py_BuildNone();
}


# Search

	{ NULL,							NULL,								NULL },

# Add before

	{"SetButtonColor", wndButtonSetColor, METH_VARARGS},