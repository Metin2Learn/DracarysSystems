# Search

	const char* CButton::GetUpVisualFileName()

# Add after

	void CButton::SetButtonColor(float r, float g, float b, float alpha)
	{
		if (!m_upVisual.IsEmpty())
			m_upVisual.SetDiffuseColor(r, g, b, alpha);
		if (!m_overVisual.IsEmpty())
			m_overVisual.SetDiffuseColor(r, g, b, alpha);
		if (!m_downVisual.IsEmpty())
			m_downVisual.SetDiffuseColor(r, g, b, alpha);
	}
