# Search

	BOOL SetDisableVisual(const char* c_szFileName);

# Add after

	void SetButtonColor(float r, float g, float b, float alpha);