# Search
	HEADER_GC_QUEST_CONFIRM = 46,
# Add after
#ifdef GUILD_WAR_COUNTER
	HEDAER_GC_GUILD_WAR = 57,
#endif

# Add

#ifdef GUILD_WAR_COUNTER
enum
{
	GUILD_STATIC_LOAD,
	GUILD_STATIC_KILL_DEAD,
	GUILD_STATIC_DMG,
	GUILD_STATIC_ADD_MEMBER,
	GUILD_STATIC_SPY,
	GUILD_STATIC_UPDATE_ONLINE,
	GUILD_STATIC_USER_COUNT,
	GUILD_STATIC_UPDATE_OBSERVER,
};
typedef struct war_static_
{
	BYTE	empire;
	char	name[CHARACTER_NAME_MAX_LEN + 1];
	BYTE	level;
	BYTE	race;
	BYTE	kill;
	BYTE	dead;
	long	skill_dmg;
	bool	is_leader;
	DWORD	guild_id;
	DWORD	pid;
	bool	spy;
	bool	online;
} war_static_ptr;
typedef struct SPacketGCGuildStatic
{
	BYTE	header;
	DWORD	size;
	BYTE	sub_index;
	BYTE	packet_size;
} TPacketGCGuildStatic;
typedef struct SPacketGCUpdateUser
{
	DWORD id0;
	int user0;
	DWORD id1;
	int user1;
	int observer;
} TPacketGCUpdateUser;
#endif
