# Add

#ifdef GUILD_WAR_COUNTER
#include "PythonPlayer.h"
#endif

# Search

		pkInstEach->Update();

# Add after

#ifdef GUILD_WAR_COUNTER
		if (CPythonPlayer::Instance().GetCameraMode())
			continue;
#endif

