# Search

	BOOL IsDoingGuildWar();

# Add after

#ifdef GUILD_WAR_COUNTER
	DWORD	GetGuildWarStaticSize() { return m_guild_war.size(); }
	void	SetGuildWarStatic(BYTE sub_index, std::vector<war_static_ptr>& m_list);
	
	war_static_ptr* StaticsIndexToPTR(UINT index);

	war_static_ptr* GetStaticsPTR(const char* name);
	war_static_ptr* GetStaticsPTR(DWORD pid);

	int GetStaticsIndex(const char* name);
	int GetStaticsIndex(DWORD pid);
#endif

# Search

	BOOL m_bGuildEnable;

# Add before

#ifdef GUILD_WAR_COUNTER
	std::vector<war_static_ptr> m_guild_war;
#endif

