# Search

	if (NEW_CancelFishing())
		return;

# Add after

#ifdef GUILD_WAR_COUNTER
	if (GetCameraMode())
	{
		m_isSmtMov = false;
		return;
	}
#endif

# Search

switch (eDirKey)

# Add before

#ifdef GUILD_WAR_COUNTER
	if (GetCameraMode())
	{
		m_isSmtMov = false;
		return;
	}
#endif

# Search

bool isAny = (isLeft || isRight || isUp || isDown);

# Add before

#ifdef GUILD_WAR_COUNTER
	if (GetCameraMode())
	{
		m_isSmtMov = false;
		return;
	}
#endif

