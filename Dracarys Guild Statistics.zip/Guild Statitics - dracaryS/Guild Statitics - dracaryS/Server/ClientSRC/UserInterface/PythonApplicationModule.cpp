# Search

	PyModule_AddIntConstant(poModule, "CAMERA_STOP", CPythonApplication::CAMERA_STOP);

# Add after

#ifdef GUILD_WAR_COUNTER
	PyModule_AddIntConstant(poModule, "GUILD_WAR_COUNTER", 1);
#else
	PyModule_AddIntConstant(poModule, "GUILD_WAR_COUNTER", 0);
#endif	