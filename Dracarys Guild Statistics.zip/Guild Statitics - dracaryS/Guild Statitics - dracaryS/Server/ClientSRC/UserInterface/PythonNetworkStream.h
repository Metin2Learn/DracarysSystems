# Search

	bool RecvChatPacket();

# Add after

#ifdef GUILD_WAR_COUNTER
	bool RecvGuildWarPacket();
#endif

