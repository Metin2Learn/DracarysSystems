# Search x2 

	CInstanceBase* pkInstMain = NEW_GetMainActorPtr();
	if (!pkInstMain) return;

# Add after x2

#ifdef GUILD_WAR_COUNTER
	if (GetCameraMode())
	{
		m_isSmtMov = false;
		return;
	}
#endif

