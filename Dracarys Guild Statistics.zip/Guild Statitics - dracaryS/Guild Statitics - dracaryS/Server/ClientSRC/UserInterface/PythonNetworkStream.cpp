# Search

		Set(HEADER_GC_DRAGON_SOUL_REFINE, CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketGCDragonSoulRefine), STATIC_SIZE_PACKET));

# Add after

#ifdef GUILD_WAR_COUNTER
		Set(HEDAER_GC_GUILD_WAR, CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketGCGuildStatic), DYNAMIC_SIZE_PACKET));
#endif

