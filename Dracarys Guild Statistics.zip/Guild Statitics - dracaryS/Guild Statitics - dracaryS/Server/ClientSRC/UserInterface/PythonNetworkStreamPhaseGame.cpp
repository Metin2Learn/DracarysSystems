# Search

		case HEADER_GC_MALL_DEL:
			ret = RecvMallItemDelPacket();
			break;


# Add after


#ifdef GUILD_WAR_COUNTER
		case HEDAER_GC_GUILD_WAR:
			ret = RecvGuildWarPacket();
			break;
#endif


# Add

#ifdef GUILD_WAR_COUNTER
bool CPythonNetworkStream::RecvGuildWarPacket()
{
	TPacketGCGuildStatic p;
	if (!Recv(sizeof(p), &p))
		return false;
	
	if (p.sub_index == 99)//empty packet.
	{		
		std::vector<war_static_ptr> m_data;
		m_data.clear();
		CPythonGuild::Instance().SetGuildWarStatic(GUILD_STATIC_LOAD, m_data);
		PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "SetStaticsStatus", Py_BuildValue("()"));
		PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "GuildWarStaticsClear", Py_BuildValue("()"));
		return true;
	}
	else if (p.sub_index == GUILD_STATIC_UPDATE_OBSERVER)
	{
		int g_Observer;
		if (!Recv(sizeof(g_Observer),&g_Observer))
			return false;
		PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "UpdateObserverCount", Py_BuildValue("(i)", g_Observer));
		return true;
	}

	switch (p.sub_index)
	{
		case GUILD_STATIC_LOAD:
		{
			std::vector<war_static_ptr> m_data;
			m_data.clear();
			m_data.resize(p.packet_size);
			if (!Recv(sizeof(war_static_ptr) * p.packet_size, m_data.data()))
				return false;
			CPythonGuild::Instance().SetGuildWarStatic(p.sub_index, m_data);

			PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "SetStaticsStatus", Py_BuildValue("()"));
			PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "GuildWarStaticsClear", Py_BuildValue("()"));
			PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "GuildWarStaticsUpdate", Py_BuildValue("()"));
		}
		break;
		case GUILD_STATIC_KILL_DEAD:
		case GUILD_STATIC_DMG:
		case GUILD_STATIC_ADD_MEMBER:
		case GUILD_STATIC_SPY:
		case GUILD_STATIC_UPDATE_ONLINE:
		{
			std::vector<war_static_ptr> m_data;
			m_data.clear();
			m_data.resize(p.packet_size);
			if (!Recv(sizeof(war_static_ptr) * p.packet_size, m_data.data()))
				return false;
			CPythonGuild::Instance().SetGuildWarStatic(p.sub_index, m_data);

			for(DWORD j=0;j < m_data.size();++j)
				PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "GuildWarStaticsSpecial", Py_BuildValue("(ii)", m_data[j].pid, p.sub_index));

			if (p.sub_index == GUILD_STATIC_KILL_DEAD && m_data.size() > 1)
				PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "AddCSMessage", Py_BuildValue("(sisi)", m_data[0].name, m_data[0].race, m_data[1].name, m_data[1].race));

		}
		break;
		case GUILD_STATIC_USER_COUNT:
		{
			int size = p.size - sizeof(p);
			TPacketGCUpdateUser user;
			if (!Recv(size, &user))
				return false;
			PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "GuildWarUpdateUserCount", Py_BuildValue("(iiiii)", user.id0, user.user0, user.id1, user.user1, user.observer));
		}
		break;
	}
	return true;
}
#endif
