
# Add

#ifdef GUILD_WAR_COUNTER
bool sortByKill(war_static_ptr& a, war_static_ptr& b)
{
	return (a.kill >= b.kill && a.dead <= b.dead && a.skill_dmg >= b.skill_dmg);
}
war_static_ptr* CPythonGuild::GetStaticsPTR(const char* name)
{
	for (DWORD i = 0; i < m_guild_war.size(); ++i)
	{
		if (strstr(name, m_guild_war[i].name))
			return &m_guild_war[i];
	}
	return NULL;
}
war_static_ptr* CPythonGuild::GetStaticsPTR(DWORD pid)
{
	for (DWORD i = 0; i < m_guild_war.size(); ++i)
	{
		if (m_guild_war[i].pid == pid)
			return &m_guild_war[i];
	}
	return NULL;
}


int CPythonGuild::GetStaticsIndex(const char* name)
{
	for (DWORD i = 0; i < m_guild_war.size(); ++i)
	{
		if (strstr(name, m_guild_war[i].name))
			return i;
	}
	return -1;
}
int CPythonGuild::GetStaticsIndex(DWORD pid)
{
	for (DWORD i = 0; i < m_guild_war.size(); ++i)
	{
		if(m_guild_war[i].pid == pid)
			return i;
	}
	return -1;
}
void CPythonGuild::SetGuildWarStatic(BYTE sub_index, std::vector<war_static_ptr>& m_list)
{
	if (sub_index == GUILD_STATIC_LOAD)
	{
		m_guild_war.clear();
		for (DWORD i = 0; i < m_list.size(); ++i)
			m_guild_war.push_back(m_list[i]);
	}
	else
	{
		for (DWORD i = 0; i < m_list.size(); ++i)
		{
			int index = GetStaticsIndex(m_list[i].pid);
			if (index == -1)
				m_guild_war.push_back(m_list[i]);
			else
			{
				war_static_ptr& ptr = m_guild_war[index];
				memcpy(&ptr, &m_list[i], sizeof(ptr));
			}
		}
	}
	std::sort(m_guild_war.begin(), m_guild_war.end(), sortByKill);
}
war_static_ptr* CPythonGuild::StaticsIndexToPTR(UINT index)
{
	if (index >= m_guild_war.size())
		return NULL;
	return &m_guild_war[index];
}
#endif

# Search

m_GuildNameMap.clear();

# Add after

#ifdef GUILD_WAR_COUNTER
	m_guild_war.clear();
#endif

# Search

void initguild()

# Add before

#ifdef GUILD_WAR_COUNTER
#include "PythonPlayer.h"
PyObject* guildStaticsSize(PyObject* poSelf, PyObject* poArgs)
{
	return Py_BuildValue("i", CPythonGuild::Instance().GetGuildWarStaticSize());
}
PyObject* guildStaticsIndexToPID(PyObject* poSelf, PyObject* poArgs)
{
	int iIndex;
	if (!PyTuple_GetInteger(poArgs, 0, &iIndex))
		return Py_BuildException();
	war_static_ptr* ptr = CPythonGuild::Instance().StaticsIndexToPTR(iIndex);
	return Py_BuildValue("i", ptr?ptr->pid:-1);

}
PyObject* guildStaticsPIDToData(PyObject* poSelf, PyObject* poArgs)
{
	int iPID;
	if (!PyTuple_GetInteger(poArgs, 0, &iPID))
		return Py_BuildException();
	int iSelf;
	if (!PyTuple_GetInteger(poArgs, 1, &iSelf))
		return Py_BuildException();

	CPythonGuild& guild_ptr = CPythonGuild::Instance();

	war_static_ptr* ptr = iSelf ? guild_ptr.GetStaticsPTR(CPythonPlayer::Instance().GetName()) : guild_ptr.GetStaticsPTR(iPID);
	if (ptr)
		return Py_BuildValue("siiiiiiiiii", ptr->name, ptr->level, ptr->race, ptr->empire, ptr->is_leader, ptr->kill, ptr->dead, ptr->skill_dmg, ptr->guild_id, ptr->spy, ptr->online);
	else
		return Py_BuildValue("siiiiiiiiii", "", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
}
PyObject* guildStaticsNameToPID(PyObject* poSelf, PyObject* poArgs)
{
	char* iName;
	if (!PyTuple_GetString(poArgs,0, &iName))
		return Py_BuildException();

	CPythonGuild& guild_ptr = CPythonGuild::Instance();
	war_static_ptr* ptr = guild_ptr.GetStaticsPTR(iName);
	return Py_BuildValue("i", ptr?ptr->pid:-1);
}
PyObject* guildStaticsTest(PyObject* poSelf, PyObject* poArgs)
{
	char* iName;
	if (!PyTuple_GetString(poArgs, 0, &iName))
		return Py_BuildException();
	int iLevel;
	if (!PyTuple_GetInteger(poArgs, 1, &iLevel))
		return Py_BuildException();
	int iRace;
	if (!PyTuple_GetInteger(poArgs, 2, &iRace))
		return Py_BuildException();
	int iEmpire;
	if (!PyTuple_GetInteger(poArgs, 3, &iEmpire))
		return Py_BuildException();
	int iIsLeader;
	if (!PyTuple_GetInteger(poArgs, 4, &iIsLeader))
		return Py_BuildException();
	int iKill;
	if (!PyTuple_GetInteger(poArgs, 5, &iKill))
		return Py_BuildException();
	int iDead;
	if (!PyTuple_GetInteger(poArgs, 6, &iDead))
		return Py_BuildException();
	int iSkillDmg;
	if (!PyTuple_GetInteger(poArgs, 7, &iSkillDmg))
		return Py_BuildException();
	int iGuildID;
	if (!PyTuple_GetInteger(poArgs, 8, &iGuildID))
		return Py_BuildException();
	int iSpy;
	if (!PyTuple_GetInteger(poArgs, 9, &iSpy))
		return Py_BuildException();
	int iOnline;
	if (!PyTuple_GetInteger(poArgs, 10, &iOnline))
		return Py_BuildException();
	int iPID;
	if (!PyTuple_GetInteger(poArgs, 11, &iPID))
		return Py_BuildException();

	war_static_ptr p;
	strcpy(p.name, iName);
	p.level = iLevel;
	p.race = iRace;
	p.empire = iEmpire;
	p.is_leader = iIsLeader;
	p.kill = iKill;
	p.dead = iDead;
	p.skill_dmg = iSkillDmg;
	p.guild_id = iGuildID;
	p.spy = iSpy;
	p.online = iOnline;
	p.pid = iPID;
	std::vector<war_static_ptr> m_data;
	m_data.clear();
	m_data.push_back(p);
	CPythonGuild::Instance().SetGuildWarStatic(1, m_data);
	return Py_BuildNone();
}
#endif

# Search

{ NULL,								NULL,								NULL },

# Add before

#ifdef GUILD_WAR_COUNTER
		{ "StaticsSize",			guildStaticsSize,						METH_VARARGS },
		{ "StaticsIndexToPID",			guildStaticsIndexToPID,						METH_VARARGS },
		{ "StaticsPIDToData",			guildStaticsPIDToData,						METH_VARARGS },
		{ "StaticsNameToPID",			guildStaticsNameToPID,						METH_VARARGS },
		{ "StaticsTest",			guildStaticsTest,						METH_VARARGS },
#endif