# Add

#define GUILD_WAR_COUNTER
