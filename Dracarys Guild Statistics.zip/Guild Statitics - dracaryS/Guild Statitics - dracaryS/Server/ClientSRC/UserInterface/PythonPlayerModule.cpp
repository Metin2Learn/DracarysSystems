# Search

void initPlayer()

# Add before

#ifdef GUILD_WAR_COUNTER
PyObject* playerGetCameraMode(PyObject* poSelf, PyObject* poArgs)
{
	return Py_BuildValue("i", CPythonPlayer::Instance().GetCameraMode());
}
PyObject* playerSetCameraMode(PyObject* poSelf, PyObject* poArgs)
{
	bool iFlag;
	if (!PyTuple_GetBoolean(poArgs, 0, &iFlag))
		return Py_BadArgument();
	CPythonPlayer::Instance().SetCameraMode(iFlag);
	return Py_BuildNone();
}
#endif

# Search

{ NULL,							NULL,								NULL },

# Add before

#ifdef GUILD_WAR_COUNTER
		{ "GetCameraMode", playerGetCameraMode, METH_VARARGS },
		{ "SetCameraMode", playerSetCameraMode, METH_VARARGS },
#endif

