# Search

	void	SetRace(DWORD dwRace);

# Add before

#ifdef GUILD_WAR_COUNTER
	bool	GetCameraMode() {return m_camera_Mode;}
	void	SetCameraMode(bool flag) {m_camera_Mode= flag;}
#endif

# Search

	DWORD					m_dwPlayTime;

# Add after

#ifdef GUILD_WAR_COUNTER
	bool					m_camera_Mode;
#endif