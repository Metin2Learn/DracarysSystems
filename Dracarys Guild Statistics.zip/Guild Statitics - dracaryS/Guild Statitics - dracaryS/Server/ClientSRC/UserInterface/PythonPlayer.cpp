# Search

	m_dwMainCharacterIndex = iIndex;

# Add after

#ifdef GUILD_WAR_COUNTER
	if (GetCameraMode())
		return;
#endif

# Search

m_skillSlotDict.clear();

# Add after

#ifdef GUILD_WAR_COUNTER
	SetCameraMode(false);
#endif