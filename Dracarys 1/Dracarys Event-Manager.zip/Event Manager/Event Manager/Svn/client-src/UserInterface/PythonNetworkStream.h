# Search

	bool SendExchangeItemDelPacket(BYTE pos);

# Add after

#ifdef ENABLE_EVENT_MANAGER
	bool RecvEventManager();
#endif
