# Search

	void		ReloadAdmin(const char* c_pData);

# Add after

#ifdef ENABLE_EVENT_MANAGER
	void		EventManager(const char* c_pData);
#endif

