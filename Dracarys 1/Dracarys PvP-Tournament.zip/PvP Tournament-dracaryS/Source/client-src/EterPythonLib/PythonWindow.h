# Search

		void ResetFrame();

# Add after

#ifdef ENABLE_PVP_TOURNAMENT
		void ClearImages();
#endif

