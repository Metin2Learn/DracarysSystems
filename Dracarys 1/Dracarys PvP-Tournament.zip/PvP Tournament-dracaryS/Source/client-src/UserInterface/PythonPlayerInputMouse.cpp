# Search 2 times

	if (!pkInstMain) return;

# add 2 times

#ifdef ENABLE_PVP_CAMERA_MODE
	if (GetCameraMode())
	{
		m_isSmtMov = false;
		return;
	}
#endif
