# Add

#ifdef ENABLE_PVP_CAMERA_MODE
#include "PythonPlayer.h"
#endif

# Search

		pkInstEach->Update();

# Add after

#ifdef ENABLE_PVP_CAMERA_MODE
		if (CPythonPlayer::Instance().GetCameraMode())
			continue;
#endif

