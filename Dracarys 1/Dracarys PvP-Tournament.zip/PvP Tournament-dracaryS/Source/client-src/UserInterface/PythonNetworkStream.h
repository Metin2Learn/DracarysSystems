# Search

	bool RecvRefineClose();

#Add after

#ifdef ENABLE_PVP_TOURNAMENT
	bool RecvPvPDuel();
#endif
