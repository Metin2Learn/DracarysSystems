# Search

	TPacketGCTime p;

# Add before

#ifdef ENABLE_REWARD_SYSTEM
	CHARACTER_MANAGER::Instance().SendRewardInfo(ch);
#endif
