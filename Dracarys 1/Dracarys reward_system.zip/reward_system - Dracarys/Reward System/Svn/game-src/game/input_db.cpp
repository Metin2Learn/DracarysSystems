# Search

	signal_timer_enable(30);

# Add after

#ifdef ENABLE_REWARD_SYSTEM
	CHARACTER_MANAGER::Instance().LoadRewardData();
#endif

