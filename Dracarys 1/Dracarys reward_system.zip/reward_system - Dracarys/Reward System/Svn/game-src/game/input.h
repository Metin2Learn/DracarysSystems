# Search

	void		IamAwake(LPDESC d, const char* c_pData);

# Add after

#ifdef ENABLE_REWARD_SYSTEM
	void		RewardInfo(const char* c_pData);
#endif

