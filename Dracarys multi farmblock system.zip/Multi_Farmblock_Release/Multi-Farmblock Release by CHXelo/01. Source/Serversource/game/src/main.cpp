//Include hinzuf�gen

#ifdef ENABLE_ANTI_MULTIPLE_FARM
#include "HAntiMultipleFarm.h"
#endif

//Unter hinzuf�gen:
//CSpeedServerManager SSManager;
//DSManager dsManager;

#ifdef ENABLE_ANTI_MULTIPLE_FARM
	CAntiMultipleFarm c_anti_multiple_farm;
#endif
