//Include hinzuf�gen

#ifdef ENABLE_ANTI_MULTIPLE_FARM
#include "HAntiMultipleFarm.h"
#endif

//Hinzuf�gen unter:
//CPythonSystem				m_pySystem;

#ifdef ENABLE_ANTI_MULTIPLE_FARM
		CAntiMultipleFarm			c_antiMultipleFarm;
#endif
