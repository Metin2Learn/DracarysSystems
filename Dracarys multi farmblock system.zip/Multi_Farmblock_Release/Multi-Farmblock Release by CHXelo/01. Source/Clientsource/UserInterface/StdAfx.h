//Hinzuf�gen unter: void initServerStateChecker();

#ifdef ENABLE_ANTI_MULTIPLE_FARM
void initAntiMultipleFarmMethods();
#endif
