
# Search

						{
							"name" : "MallButton",
							"type" : "button",

							"x" : 118,
							"y" : 148,

							"tooltip_text" : uiScriptLocale.MALL_TITLE,

							"default_image" : "d:/ymir work/ui/game/TaskBar/Mall_Button_01.tga",
							"over_image" : "d:/ymir work/ui/game/TaskBar/Mall_Button_02.tga",
							"down_image" : "d:/ymir work/ui/game/TaskBar/Mall_Button_03.tga",
						},


# Add after

						{
							"name" : "OffButton",
							"type" : "button",
							"x" :80,
							"y" :107,
							"tooltip_text" : uiScriptLocale.OFFLINE_SHOP_TITLE,
							"default_image" : "d:/ymir work/ui/game/offlineshop/new_offline_shop_1.tga",
							"over_image" : "d:/ymir work/ui/game/offlineshop/new_offline_shop_2.tga",
							"down_image" : "d:/ymir work/ui/game/offlineshop/new_offline_shop_3.tga",
						},