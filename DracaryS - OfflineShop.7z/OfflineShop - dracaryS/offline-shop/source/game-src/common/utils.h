# Add

inline bool str_to_number (unsigned long long& out, const char *in)
{
	if (0==in || 0==in[0])	return false;

	out = (unsigned long long) strtoul(in, NULL, 10);
	return true;
}

extern bool getInjectText(const char* data);