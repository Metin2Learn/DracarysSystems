# Search

struct FuncPurge

# Add in this ptr

#ifdef ENABLE_OFFLINESHOP_SYSTEM
		&& !pkChr->IsOfflineShopNPC()
#endif