# Add

#ifdef ENABLE_OFFLINESHOP_SYSTEM
	{ CInstanceBase::EFFECT_REFINED + 37, "Bip01", "d:/ymir work/effect/etc/myshop/2.mse", true},
#endif


